import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "jsr:@supabase/supabase-js@2";

const SUPABASE_URL = Deno.env.get('SUPABASE_URL')!;
const SUPABASE_SERVICE_KEY = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;

const BLOCKED_EXTENSIONS = ['.exe','.bat','.sh','.cmd','.ps1','.vbs','.js','.jar','.php','.py','.rb','.pl','.msi','.dll','.so','.elf'];
const BLOCKED_MIME_PREFIXES = ['application/x-executable','application/x-msdownload','application/x-sh','text/x-script'];
const ALLOWED_MIMES: Record<string, string[]> = {
  'item-evidence':    ['image/jpeg','image/png','image/webp','image/gif'],
  'dispute-evidence': ['image/jpeg','image/png','image/webp','application/pdf','video/mp4'],
};
const MAX_SIZES: Record<string, number> = {
  'item-evidence':    5 * 1024 * 1024,
  'dispute-evidence': 10 * 1024 * 1024,
};

type ScanPayload = {
  bucket: string;
  file_path: string;
  file_name: string;
  file_mime: string;
  file_size: number;
  uploaded_by: string;
  item_id?: string;
};

function scanFile(p: ScanPayload): { safe: boolean; reason?: string; checks: string[] } {
  const checks: string[] = [];
  const ext = '.' + p.file_name.split('.').pop()?.toLowerCase();

  if (BLOCKED_EXTENSIONS.includes(ext)) return { safe: false, reason: `Ekstensi diblokir: ${ext}`, checks };
  checks.push('extension_ok');

  const allowed = ALLOWED_MIMES[p.bucket] || [];
  if (!allowed.includes(p.file_mime)) return { safe: false, reason: `MIME tidak diizinkan: ${p.file_mime}`, checks };
  checks.push('mime_allowed');

  if (BLOCKED_MIME_PREFIXES.some(x => p.file_mime.startsWith(x))) return { safe: false, reason: `MIME executable: ${p.file_mime}`, checks };
  checks.push('mime_not_executable');

  const maxSize = MAX_SIZES[p.bucket] || 5 * 1024 * 1024;
  if (p.file_size > maxSize) return { safe: false, reason: `File terlalu besar: ${(p.file_size/1024/1024).toFixed(2)}MB`, checks };
  checks.push('size_ok');

  const parts = p.file_name.toLowerCase().split('.');
  if (parts.length > 2 && BLOCKED_EXTENSIONS.includes('.' + parts[parts.length - 2])) {
    return { safe: false, reason: `Double extension: ${p.file_name}`, checks };
  }
  checks.push('no_double_extension');

  if (p.file_name.includes('\0') || p.file_name.includes('..') || p.file_name.includes('/')) {
    return { safe: false, reason: 'Nama file berbahaya', checks };
  }
  checks.push('filename_safe');

  return { safe: true, checks };
}

Deno.serve(async (req: Request) => {
  if (req.method !== 'POST') return new Response('Method Not Allowed', { status: 405 });

  const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_KEY);
  try {
    const payload: ScanPayload = await req.json();
    if (!payload.bucket || !payload.file_name || !payload.file_mime || !payload.uploaded_by) {
      return new Response(JSON.stringify({ error: 'Missing required fields' }), { status: 400 });
    }

    const result = scanFile(payload);

    await supabase.from('security_events').insert({
      event_type: result.safe ? 'file_scan_passed' : 'file_scan_blocked',
      severity: result.safe ? 'info' : 'high',
      user_id: payload.uploaded_by,
      details: { bucket: payload.bucket, file_name: payload.file_name, file_mime: payload.file_mime, scan_result: result },
    });

    if (!result.safe && payload.file_path) {
      const { error: delErr } = await supabase.storage.from(payload.bucket).remove([payload.file_path]);
      if (delErr) console.error('[HAQ] Delete failed:', delErr);
      await supabase.rpc('apply_progressive_penalty', { p_user_id: payload.uploaded_by, p_action: 'malicious_upload' });
    }

    return new Response(JSON.stringify(result), {
      status: result.safe ? 200 : 422,
      headers: { 'Content-Type': 'application/json' },
    });
  } catch (err) {
    console.error('[HAQ] scan-file error:', err);
    return new Response(JSON.stringify({ error: String(err) }), { status: 500 });
  }
});
