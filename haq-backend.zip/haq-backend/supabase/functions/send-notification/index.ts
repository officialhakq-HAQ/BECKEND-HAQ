import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "jsr:@supabase/supabase-js@2";

const SUPABASE_URL = Deno.env.get('SUPABASE_URL')!;
const SUPABASE_SERVICE_KEY = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
const RESEND_API_KEY = Deno.env.get('RESEND_API_KEY') ?? '';
const FROM_EMAIL = Deno.env.get('FROM_EMAIL') ?? 'noreply@haq.app';
const APP_NAME = 'HAQ — Ownership Registry';

type NotifPayload = {
  type: 'transfer_initiated' | 'transfer_confirmed' | 'transfer_declined' | 'transfer_expired'
      | 'dispute_opened' | 'dispute_resolved'
      | 'item_locked' | 'account_locked';
  recipient_email: string;
  recipient_name?: string;
  item_name?: string;
  haq_id?: string;
  actor_email?: string;
  note?: string;
  expires_at?: string;
};

function buildEmailContent(payload: NotifPayload): { subject: string; html: string } {
  const name = payload.recipient_name || payload.recipient_email.split('@')[0];
  const item = payload.item_name ? `<strong>${payload.item_name}</strong>` : 'item Anda';
  const haq = payload.haq_id
    ? `<code style="background:#1a2332;padding:2px 6px;border-radius:4px;font-size:12px;color:#00C896">${payload.haq_id}</code>`
    : '';

  const wrap = (body: string) => `<!DOCTYPE html><html><body style="margin:0;padding:16px;background:#080D14">
    <div style="font-family:'Segoe UI',Arial,sans-serif;max-width:560px;margin:0 auto;background:#0D1117;color:#F0F6FC;border:1px solid #30363D;border-radius:8px;overflow:hidden">
      <div style="background:linear-gradient(135deg,#0f2a1e,#0D1117);padding:28px 32px;border-bottom:1px solid #30363D">
        <div style="font-weight:900;font-size:20px;color:#00C896">HAQ</div>
        <div style="font-size:11px;color:#8B949E">Ownership Registry</div>
      </div>
      <div style="padding:28px 32px">${body}</div>
      <div style="padding:16px 32px;border-top:1px solid #30363D;font-size:11px;color:#484F58;text-align:center">
        Email ini dikirim otomatis. Jangan balas email ini.<br>© 2026 HAQ
      </div>
    </div>
  </body></html>`;

  const templates: Record<NotifPayload['type'], { subject: string; body: string }> = {
    transfer_initiated: {
      subject: `[HAQ] Transfer Item Masuk — ${payload.item_name || 'Item'}`,
      body: `<p>Halo <strong>${name}</strong>,</p>
        <p>Anda menerima transfer kepemilikan untuk ${item} ${haq}</p>
        <p>Pengirim: <strong>${payload.actor_email || 'Pengguna HAQ'}</strong></p>
        ${payload.expires_at ? `<p style="color:#F59E0B">⏰ Kedaluwarsa: <strong>${new Date(payload.expires_at).toLocaleString('id-ID')}</strong></p>` : ''}
        <div style="margin:24px 0">
          <a href="https://haq.app/dashboard/transfer" style="background:#00C896;color:#000;padding:10px 20px;border-radius:6px;text-decoration:none;font-weight:600">Lihat Transfer →</a>
        </div>`,
    },
    transfer_confirmed: {
      subject: `[HAQ] Transfer Dikonfirmasi — ${payload.item_name || 'Item'}`,
      body: `<p>Halo <strong>${name}</strong>,</p><p>Transfer ${item} ${haq} telah <span style="color:#00C896"><strong>dikonfirmasi</strong></span>.</p>`,
    },
    transfer_declined: {
      subject: `[HAQ] Transfer Ditolak — ${payload.item_name || 'Item'}`,
      body: `<p>Halo <strong>${name}</strong>,</p><p>Transfer ${item} ${haq} <span style="color:#EF4444"><strong>ditolak</strong></span>. Item tetap milik Anda.</p>`,
    },
    transfer_expired: {
      subject: `[HAQ] Transfer Kedaluwarsa — ${payload.item_name || 'Item'}`,
      body: `<p>Halo <strong>${name}</strong>,</p><p>Transfer ${item} ${haq} telah <span style="color:#F59E0B"><strong>kedaluwarsa</strong></span>. Item tetap milik Anda.</p>`,
    },
    dispute_opened: {
      subject: `[HAQ] Sengketa Dibuka — ${payload.item_name || 'Item'}`,
      body: `<p>Halo <strong>${name}</strong>,</p><p>Sengketa dibuka untuk ${item} ${haq}</p><p>Alasan: <em>${payload.note || '—'}</em></p><p style="color:#F59E0B">⚠ Transfer diblokir sementara.</p>`,
    },
    dispute_resolved: {
      subject: `[HAQ] Sengketa Diselesaikan — ${payload.item_name || 'Item'}`,
      body: `<p>Halo <strong>${name}</strong>,</p><p>Sengketa untuk ${item} ${haq} telah <span style="color:#00C896"><strong>diselesaikan</strong></span>.</p>${payload.note ? `<p>Catatan admin: <em>${payload.note}</em></p>` : ''}`,
    },
    item_locked: {
      subject: `[HAQ] Item Dikunci — ${payload.item_name || 'Item'}`,
      body: `<p>Halo <strong>${name}</strong>,</p><p>${item} ${haq} telah <span style="color:#F59E0B"><strong>dikunci</strong></span> karena anomali.</p>`,
    },
    account_locked: {
      subject: '[HAQ] Akun Anda Dikunci',
      body: `<p>Halo <strong>${name}</strong>,</p><p>Akun HAQ Anda telah <span style="color:#EF4444"><strong>dikunci</strong></span>.</p>${payload.note ? `<p>Alasan: <em>${payload.note}</em></p>` : ''}`,
    },
  };

  const t = templates[payload.type];
  return { subject: t.subject, html: wrap(t.body) };
}

Deno.serve(async (req: Request) => {
  if (req.method !== 'POST') return new Response('Method Not Allowed', { status: 405 });

  try {
    const payload: NotifPayload = await req.json();
    if (!payload.type || !payload.recipient_email) {
      return new Response(JSON.stringify({ error: 'Missing: type, recipient_email' }), { status: 400 });
    }

    const { subject, html } = buildEmailContent(payload);

    let sent = false;
    if (RESEND_API_KEY) {
      const res = await fetch('https://api.resend.com/emails', {
        method: 'POST',
        headers: { 'Authorization': `Bearer ${RESEND_API_KEY}`, 'Content-Type': 'application/json' },
        body: JSON.stringify({ from: `${APP_NAME} <${FROM_EMAIL}>`, to: payload.recipient_email, subject, html }),
      });
      sent = res.ok;
      if (!res.ok) console.error('[HAQ] Resend error:', await res.text());
    } else {
      console.warn('[HAQ] RESEND_API_KEY not set — skipping email');
    }

    const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_KEY);
    await supabase.from('security_events').insert({
      event_type: 'notification_sent', severity: 'info',
      details: { type: payload.type, to: payload.recipient_email, sent, subject },
    });

    return new Response(JSON.stringify({ success: true, sent }), { headers: { 'Content-Type': 'application/json' } });
  } catch (err) {
    console.error('[HAQ] error:', err);
    return new Response(JSON.stringify({ error: String(err) }), { status: 500 });
  }
});
