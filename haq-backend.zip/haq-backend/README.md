# haq-backend

Backend HAQ V1 — Supabase (PostgreSQL + Edge Functions).

## Stack
- **Database**: PostgreSQL 17.6 via Supabase (`waedvqhzhxmdpjfifvtz`, ap-southeast-1)
- **Edge Functions**: Deno (send-notification, scan-file)
- **Auth**: Supabase Auth + RLS
- **Storage**: Supabase Storage (item-evidence, dispute-evidence)

## Struktur Repo
```
haq-backend/
├── supabase/
│   ├── config.toml           # Supabase project config
│   ├── migrations/           # 75 migrasi berurutan (v1 → v22)
│   └── functions/
│       ├── send-notification/ # Email notifikasi otomatis
│       └── scan-file/         # Virus/malware scan upload
├── docs/
│   ├── SCHEMA.md             # Dokumentasi semua tabel & RPC
│   ├── SECURITY.md           # Security model & RLS policies
│   └── DEPLOY.md             # Panduan deploy & env vars
└── .github/workflows/
    └── deploy-functions.yml  # Auto-deploy edge functions ke Supabase
```

## Setup Lokal

```bash
# Install Supabase CLI
npm install -g supabase

# Link ke project
supabase link --project-ref waedvqhzhxmdpjfifvtz

# Lihat status migrations
supabase db diff

# Deploy edge functions
supabase functions deploy send-notification
supabase functions deploy scan-file
```

## Environment Variables (Edge Functions)

Set di Supabase Dashboard → Project Settings → Edge Functions:

| Variable | Keterangan |
|----------|-----------|
| `SUPABASE_URL` | Auto-set oleh Supabase |
| `SUPABASE_SERVICE_ROLE_KEY` | Auto-set oleh Supabase |
| `RESEND_API_KEY` | API key dari resend.com untuk kirim email |
| `FROM_EMAIL` | Alamat pengirim, misal `noreply@haq.app` |

## Migration Workflow

Setiap perubahan schema harus dibuat sebagai file migration baru:

```bash
# Buat migration baru
supabase migration new nama_perubahan

# Edit file di supabase/migrations/TIMESTAMP_nama_perubahan.sql
# Lalu push ke Supabase
supabase db push
```

**Jangan** edit migration lama — semua perubahan harus migration baru.

## Edge Functions

### send-notification
Kirim email otomatis untuk event: transfer_initiated, transfer_confirmed,
transfer_declined, transfer_expired, dispute_opened, dispute_resolved,
item_locked, account_locked.

Dipanggil via DB trigger (`fn_trigger_notify_on_ownership_event`, `fn_trigger_notify_on_dispute`).

### scan-file
Scan file sebelum disimpan di storage. Cek ekstensi, MIME type, ukuran,
double extension, dan path traversal. File berbahaya otomatis dihapus
dan user mendapat penalti.

## Database Stats (v22, Mar 2026)
- 56 tabel/view
- 110+ functions
- 24 triggers
- 5 cron jobs
- 75 migrations
- 100% RLS enabled
- Security score: 9/10
