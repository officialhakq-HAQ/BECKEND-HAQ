# HAQ Backend — Deploy Guide

## Prerequisites
- Supabase CLI: `npm install -g supabase`
- Akun Supabase dengan project aktif

## Setup Lokal

```bash
# 1. Clone repo
git clone https://github.com/your-org/haq-backend.git
cd haq-backend

# 2. Link ke Supabase project
supabase link --project-ref waedvqhzhxmdpjfifvtz

# 3. Cek status (pastikan semua migration sudah applied)
supabase migration list
```

## Deploy Edge Functions

```bash
# Deploy semua sekaligus
supabase functions deploy send-notification
supabase functions deploy scan-file

# Set environment variables
supabase secrets set RESEND_API_KEY=your_key_here
supabase secrets set FROM_EMAIL=noreply@haq.app
```

## Tambah Migration Baru

```bash
# 1. Buat file migration
supabase migration new nama_perubahan_kamu

# 2. Edit file SQL yang dibuat di supabase/migrations/
# 3. Test di local (opsional)
supabase db reset --local

# 4. Push ke production
supabase db push
```

## Environment Variables (Edge Functions)

| Variable | Source | Keterangan |
|----------|--------|-----------|
| `SUPABASE_URL` | Auto (Supabase) | URL project |
| `SUPABASE_SERVICE_ROLE_KEY` | Auto (Supabase) | Service role key |
| `RESEND_API_KEY` | Manual | API key dari resend.com |
| `FROM_EMAIL` | Manual | Email pengirim |

## GitHub Actions

File `.github/workflows/deploy-functions.yml` otomatis deploy edge functions
setiap kali ada push ke branch `main` yang mengubah file di `supabase/functions/`.

Setup secrets di GitHub repo:
- `SUPABASE_ACCESS_TOKEN` — dari https://supabase.com/dashboard/account/tokens
- `SUPABASE_PROJECT_REF` — `waedvqhzhxmdpjfifvtz`

## Project Info

| Key | Value |
|-----|-------|
| Project ID | `waedvqhzhxmdpjfifvtz` |
| Region | `ap-southeast-1` (Singapore) |
| PostgreSQL | 17.6 |
| Schema Version | v22 (Mar 2026) |
| Migrations | 75 files |
