# HAQ V1 — Database Schema

**Project**: waedvqhzhxmdpjfifvtz · ap-southeast-1 · PostgreSQL 17.6

## Tabel Utama

| Tabel | Deskripsi |
|-------|-----------|
| `profiles` | Data user (display_name, role, account_status) |
| `items` | Item terdaftar (haq_id, current_owner_id, status, chain) |
| `ownership_logs` | Log kepemilikan dengan SHA256 hash chain (immutable) |
| `disputes` | Sengketa kepemilikan |
| `item_evidence` | Bukti kepemilikan (foto, dokumen) |
| `user_quotas` | Kuota harian per user |
| `user_penalties` | Penalti progresif (cooldown, soft ban) |
| `security_events` | Log event keamanan |
| `rate_limits` | Rate limiting per user per action |
| `haq_secrets` | HMAC key aktif |

## Partisi

| Tabel | Partisi |
|-------|---------|
| `ownership_logs_partitioned` | Q1-Q4 2025, Q1-Q4 2026 + overflow |
| `activity_logs_partitioned` | Q1-Q2 2026 + overflow |

## Views Admin

| View | Deskripsi |
|------|-----------|
| `admin_system_overview` | Ringkasan sistem |
| `admin_open_disputes` | Sengketa terbuka |
| `admin_active_locks` | Item/akun terkunci |
| `v_admin_chain_integrity` | Status chain semua item |
| `chain_integrity_status` | Detail integritas chain |
| `suspicious_users` | User mencurigakan |

## Views Audit

| View | Deskripsi |
|------|-----------|
| `audit_missing_genesis` | Item tanpa log genesis |
| `audit_sequence_gaps` | Gap urutan sequence di chain |
| `audit_transfer_count_mismatch` | Inkonsistensi transfer count |
| `audit_unhashed_logs` | Log tanpa HMAC |
| `double_transfer_anomaly` | Transfer ganda anomali |
| `orphan_pending_transfers` | Transfer pending tanpa item |
| `transfer_velocity` | Kecepatan transfer per user |

## RPC Utama (Frontend)

| RPC | Keterangan |
|-----|-----------|
| `rpc_register_item` | Daftarkan item baru |
| `rpc_fetch_my_items` | Ambil semua item milik user |
| `rpc_item_detail` | Detail item + chain history |
| `rpc_initiate_transfer` | Mulai transfer ke penerima |
| `rpc_confirm_transfer` | Konfirmasi transfer masuk |
| `rpc_decline_transfer` | Tolak transfer masuk |
| `rpc_fetch_incoming_transfers` | Daftar transfer masuk |
| `rpc_verify_item` | Verifikasi chain item |
| `rpc_file_dispute` | Ajukan sengketa |
| `rpc_fetch_my_disputes` | Daftar sengketa user |
| `rpc_register_evidence` | Upload bukti kepemilikan |
| `rpc_get_dashboard_stats` | Statistik dashboard |
| `rpc_lookup_user_by_email` | Cari user by email (untuk transfer) |
| `rpc_update_display_name` | Update nama tampilan |
| `rpc_anonymize_user_profile` | GDPR anonymize |
| `get_my_quota` | Kuota user saat ini |

## RPC Admin (butuh fn_is_admin())

| RPC | Keterangan |
|-----|-----------|
| `rpc_admin_list_users` | Daftar semua user |
| `rpc_admin_list_disputes` | Daftar semua dispute |
| `rpc_admin_list_security_events` | Log security events |
| `rpc_admin_lock_user` | Kunci akun user |
| `rpc_admin_unlock_user` | Buka kunci akun user |
| `rpc_admin_resolve_dispute` | Selesaikan dispute |
| `admin_grant_quota` | Tambah kuota user |
| `admin_lift_penalty` | Cabut penalti user |
| `admin_unlock_item` | Buka kunci item |
| `fn_rotate_hmac_key` | Rotasi HMAC signing key |

## Cron Jobs

| Job | Jadwal | Fungsi |
|-----|--------|--------|
| `haq-cancel-expired-transfers` | `0 * * * *` | Batalkan transfer expired |
| `haq-daily-chain-snapshot` | `0 1 * * *` | Snapshot chain harian |
| `haq-daily-root-hash` | `30 1 * * *` | Aggregate root hash |
| `haq-reset-daily-quotas` | `0 0 * * *` | Reset kuota harian |
| `haq-verify-all-chains` | `0 2 * * *` | Verifikasi semua chain |

## Storage Buckets

| Bucket | Akses | Max Size | MIME Allowed |
|--------|-------|----------|--------------|
| `item-evidence` | Private | 5MB | JPEG, PNG, WebP, GIF |
| `dispute-evidence` | Private | 10MB | JPEG, PNG, WebP, PDF, MP4 |

## Triggers

| Trigger | Tabel | Event |
|---------|-------|-------|
| `ownership_log_hash_chain` | ownership_logs | BEFORE INSERT — SHA256 chain |
| `on_ownership_log_insert` | ownership_logs | AFTER INSERT — HMAC sign |
| `on_transfer_spike_lock_item` | ownership_logs | AFTER INSERT — auto-lock anomali |
| `enforce_dispute_transfer_block` | ownership_logs | BEFORE INSERT — blokir jika dispute |
| `on_item_registration_anomaly` | items | AFTER INSERT — deteksi anomali |
| `on_profile_created_init_quota` | profiles | AFTER INSERT — init quota |
| `on_security_event_auto_lock` | security_events | AFTER INSERT — auto-lock akun |
| `trg_notify_on_ownership_event` | ownership_logs | AFTER INSERT — kirim email |
| `trg_notify_on_dispute` | disputes | AFTER INSERT/UPDATE — kirim email |
| + 8 immutability triggers | chain_anchors, ownership_logs, items, dll | BEFORE DELETE/UPDATE |
